# Bản 1.3.1 – ghi chú

Script TungTomVND giữ NGUYÊN, không sửa. Chế độ ngủ đã được GỠ BỎ (giữ logo không còn vào màn hình ngủ nữa).

## Cài đặt mới (bấm nút logo → bảng tiện ích, hai công tắc ở đầu danh sách)
- **Xoay màn hình**: Bật = tự xoay theo cảm biến (kể cả khi hệ thống đang khoá xoay). Tắt = khoá đúng hướng đang hiển thị.
- **Treo khi tắt màn hình**: Bật = bấm nút nguồn tắt màn hình, game vẫn chạy.
  Cách hoạt động: dịch vụ nền có thông báo + khoá CPU/Wi-Fi + WebView luôn báo "đang hiển thị" để trang không bị làm chậm.
  Lần đầu app sẽ hỏi quyền thông báo (Android 13+) và quyền bỏ tối ưu pin – nên bấm Cho phép, nếu không một số máy (Xiaomi, Oppo, Samsung…) vẫn tự giết app.
  Tắt màn hình thì độ họa tự xuống "Tối đa" để đỡ nóng và hao pin, bật lại màn hình sẽ trở về mức theo nhiệt độ.

## Chống nóng máy (tự động, không cần bật tắt)
Dùng bộ giảm đồ họa của PokeSurvivorTool-Lite (assets/ttv_engine.js, MIT):
- Mát (< 38°C): "Nhẹ"  = giảm độ phân giải ≤1x, bỏ bóng/glow, tắt hiệu ứng CSS
- Ấm (38–42°C): "Vừa" = thêm bỏ số sát thương/bụi, vẽ 1/2 số khung hình
- Nóng (≥ 42°C) hoặc đang tắt màn hình: "Tối đa" = độ phân giải 0.5x, vẽ 1/3 số khung hình, bỏ nền đất
Logic game/bot vẫn chạy đủ tốc độ, chỉ phần VẼ bị giảm. Có độ trễ 2°C để không đổi mức liên tục.

## Màn hình chào
Mở app lên sẽ hiện logo + tên TungTomVND (tối thiểu 1,5 giây, tự ẩn khi trang game tải xong, tối đa 5 giây).
